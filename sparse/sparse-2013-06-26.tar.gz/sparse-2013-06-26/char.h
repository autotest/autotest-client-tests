extern void get_char_constant(struct token *, unsigned long long *);
extern struct token *get_string_constant(struct token *, struct expression *);
