
#include <gtk/gtk.h>
#include "lib.h"

extern void treeview_main(struct symbol_list *syms);


