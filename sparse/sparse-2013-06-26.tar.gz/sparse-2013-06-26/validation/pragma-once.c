#pragma once
#include "pragma-once.c"
/*
 * check-name: #pragma once
 */
