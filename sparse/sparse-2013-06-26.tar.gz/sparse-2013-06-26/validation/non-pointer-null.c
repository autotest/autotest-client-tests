static void *p = 0;
/*
 * check-name: Using plain integer as NULL pointer
 *
 * check-error-start
non-pointer-null.c:1:18: warning: Using plain integer as NULL pointer
 * check-error-end
 */
