static int add_char(void)
{
	return (char) 127 + (char) 127 + (char) 2;
}
/*
 * check-name: Integer promotions
 */
