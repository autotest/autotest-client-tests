static void foo(enum bar baz);

/*
 * check-name: enum not in scope
 * check-known-to-fail
 */
