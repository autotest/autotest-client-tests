typedef unsigned int u32;
typedef u32 __attribute__((vector_size(16))) sse128_t;

/*
 * check-name: attribute vector_size
 */

