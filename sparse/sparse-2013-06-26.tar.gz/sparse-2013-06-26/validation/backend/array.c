static char array[128];

/*
 * check-name: Array code generation
 * check-command: ./sparsec -c $file -o tmp.o
 */
