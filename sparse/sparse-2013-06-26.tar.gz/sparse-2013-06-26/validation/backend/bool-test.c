static _Bool return_false(void)
{
	return 0;
}

/*
 * check-name: Boolean type code generation
 * check-command: ./sparsec -c $file -o tmp.o
 */
